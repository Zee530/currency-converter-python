#define variables

currencies = ['US Dollars (USD)', 'Euro (EUR)', 'Japanese Yen (JPY)', 'British Pound (GBP)', 'Nigerian Naira (NGN)']

currencyFrom = 0

currencyTo = 0

engine = []

amount = 0
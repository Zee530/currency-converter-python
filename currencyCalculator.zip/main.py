from welcome import welcome

if __name__ == '__main__':
    welcome()